# splunk
This is splunk official source that they use, it was leaked by me aka fro#1337
# How to setup
go to setup.php and then setup ur site/gen
